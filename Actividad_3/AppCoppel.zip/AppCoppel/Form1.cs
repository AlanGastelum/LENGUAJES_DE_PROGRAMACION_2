﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppCoppel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.empleadoTableAdapter.Fill(this.coppelDataSet.Empleado);

            this.directivosTableAdapter.Fill(this.coppelDataSet.Directivos);

            this.centrodeTrabajoTableAdapter.Fill(this.coppelDataSet.CentrodeTrabajo);

            this.puestosTableAdapter.Fill(this.coppelDataSet.Puestos);
        }
    }
}


