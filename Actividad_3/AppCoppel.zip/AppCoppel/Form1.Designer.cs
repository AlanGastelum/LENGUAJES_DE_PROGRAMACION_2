﻿namespace AppCoppel
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabEmpleados = new System.Windows.Forms.TabPage();
            this.dgvEmpleados = new System.Windows.Forms.DataGridView();
            this.numEmpleadoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellidoPDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellidoMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaNacimientoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rFCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numCentroDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numPuestoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcionPuestoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.directivosDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.empleadoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.coppelDataSet = new AppCoppel.CoppelDataSet();
            this.tabDirectivos = new System.Windows.Forms.TabPage();
            this.dgvDirectivos = new System.Windows.Forms.DataGridView();
            this.numEmpleadoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numCentroSupervisaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prestacionesDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.directivosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabCentroTrabajo = new System.Windows.Forms.TabPage();
            this.dgvCentroTrabajo = new System.Windows.Forms.DataGridView();
            this.numCentroDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreCentroDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ciudadDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.centrodeTrabajoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPuestos = new System.Windows.Forms.TabPage();
            this.dgvPuestos = new System.Windows.Forms.DataGridView();
            this.numPuestoDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.puestoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.puestosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.puestosTableAdapter = new AppCoppel.CoppelDataSetTableAdapters.PuestosTableAdapter();
            this.tableAdapterManager = new AppCoppel.CoppelDataSetTableAdapters.TableAdapterManager();
            this.centrodeTrabajoTableAdapter = new AppCoppel.CoppelDataSetTableAdapters.CentrodeTrabajoTableAdapter();
            this.directivosTableAdapter = new AppCoppel.CoppelDataSetTableAdapters.DirectivosTableAdapter();
            this.empleadoTableAdapter = new AppCoppel.CoppelDataSetTableAdapters.EmpleadoTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabEmpleados.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.coppelDataSet)).BeginInit();
            this.tabDirectivos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDirectivos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.directivosBindingSource)).BeginInit();
            this.tabCentroTrabajo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCentroTrabajo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.centrodeTrabajoBindingSource)).BeginInit();
            this.tabPuestos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPuestos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.puestosBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabEmpleados);
            this.tabControl1.Controls.Add(this.tabDirectivos);
            this.tabControl1.Controls.Add(this.tabCentroTrabajo);
            this.tabControl1.Controls.Add(this.tabPuestos);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1747, 506);
            this.tabControl1.TabIndex = 0;
            // 
            // tabEmpleados
            // 
            this.tabEmpleados.Controls.Add(this.dgvEmpleados);
            this.tabEmpleados.Location = new System.Drawing.Point(4, 37);
            this.tabEmpleados.Margin = new System.Windows.Forms.Padding(4);
            this.tabEmpleados.Name = "tabEmpleados";
            this.tabEmpleados.Padding = new System.Windows.Forms.Padding(4);
            this.tabEmpleados.Size = new System.Drawing.Size(1739, 465);
            this.tabEmpleados.TabIndex = 0;
            this.tabEmpleados.Text = "Empleado";
            this.tabEmpleados.UseVisualStyleBackColor = true;
            // 
            // dgvEmpleados
            // 
            this.dgvEmpleados.AllowUserToAddRows = false;
            this.dgvEmpleados.AllowUserToDeleteRows = false;
            this.dgvEmpleados.AutoGenerateColumns = false;
            this.dgvEmpleados.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvEmpleados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEmpleados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numEmpleadoDataGridViewTextBoxColumn1,
            this.nombreDataGridViewTextBoxColumn,
            this.apellidoPDataGridViewTextBoxColumn,
            this.apellidoMDataGridViewTextBoxColumn,
            this.fechaNacimientoDataGridViewTextBoxColumn,
            this.rFCDataGridViewTextBoxColumn,
            this.numCentroDataGridViewTextBoxColumn1,
            this.numPuestoDataGridViewTextBoxColumn,
            this.descripcionPuestoDataGridViewTextBoxColumn,
            this.directivosDataGridViewCheckBoxColumn});
            this.dgvEmpleados.DataSource = this.empleadoBindingSource;
            this.dgvEmpleados.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvEmpleados.Location = new System.Drawing.Point(4, 4);
            this.dgvEmpleados.MultiSelect = false;
            this.dgvEmpleados.Name = "dgvEmpleados";
            this.dgvEmpleados.ReadOnly = true;
            this.dgvEmpleados.RowHeadersWidth = 62;
            this.dgvEmpleados.RowTemplate.Height = 28;
            this.dgvEmpleados.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEmpleados.Size = new System.Drawing.Size(1731, 457);
            this.dgvEmpleados.TabIndex = 0;
            // 
            // numEmpleadoDataGridViewTextBoxColumn1
            // 
            this.numEmpleadoDataGridViewTextBoxColumn1.DataPropertyName = "numEmpleado";
            this.numEmpleadoDataGridViewTextBoxColumn1.HeaderText = "numEmpleado";
            this.numEmpleadoDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.numEmpleadoDataGridViewTextBoxColumn1.Name = "numEmpleadoDataGridViewTextBoxColumn1";
            this.numEmpleadoDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // nombreDataGridViewTextBoxColumn
            // 
            this.nombreDataGridViewTextBoxColumn.DataPropertyName = "nombre";
            this.nombreDataGridViewTextBoxColumn.HeaderText = "nombre";
            this.nombreDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.nombreDataGridViewTextBoxColumn.Name = "nombreDataGridViewTextBoxColumn";
            this.nombreDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // apellidoPDataGridViewTextBoxColumn
            // 
            this.apellidoPDataGridViewTextBoxColumn.DataPropertyName = "apellidoP";
            this.apellidoPDataGridViewTextBoxColumn.HeaderText = "apellidoP";
            this.apellidoPDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.apellidoPDataGridViewTextBoxColumn.Name = "apellidoPDataGridViewTextBoxColumn";
            this.apellidoPDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // apellidoMDataGridViewTextBoxColumn
            // 
            this.apellidoMDataGridViewTextBoxColumn.DataPropertyName = "apellidoM";
            this.apellidoMDataGridViewTextBoxColumn.HeaderText = "apellidoM";
            this.apellidoMDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.apellidoMDataGridViewTextBoxColumn.Name = "apellidoMDataGridViewTextBoxColumn";
            this.apellidoMDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fechaNacimientoDataGridViewTextBoxColumn
            // 
            this.fechaNacimientoDataGridViewTextBoxColumn.DataPropertyName = "fechaNacimiento";
            this.fechaNacimientoDataGridViewTextBoxColumn.HeaderText = "fechaNacimiento";
            this.fechaNacimientoDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.fechaNacimientoDataGridViewTextBoxColumn.Name = "fechaNacimientoDataGridViewTextBoxColumn";
            this.fechaNacimientoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // rFCDataGridViewTextBoxColumn
            // 
            this.rFCDataGridViewTextBoxColumn.DataPropertyName = "RFC";
            this.rFCDataGridViewTextBoxColumn.HeaderText = "RFC";
            this.rFCDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.rFCDataGridViewTextBoxColumn.Name = "rFCDataGridViewTextBoxColumn";
            this.rFCDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // numCentroDataGridViewTextBoxColumn1
            // 
            this.numCentroDataGridViewTextBoxColumn1.DataPropertyName = "numCentro";
            this.numCentroDataGridViewTextBoxColumn1.HeaderText = "numCentro";
            this.numCentroDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.numCentroDataGridViewTextBoxColumn1.Name = "numCentroDataGridViewTextBoxColumn1";
            this.numCentroDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // numPuestoDataGridViewTextBoxColumn
            // 
            this.numPuestoDataGridViewTextBoxColumn.DataPropertyName = "numPuesto";
            this.numPuestoDataGridViewTextBoxColumn.HeaderText = "numPuesto";
            this.numPuestoDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.numPuestoDataGridViewTextBoxColumn.Name = "numPuestoDataGridViewTextBoxColumn";
            this.numPuestoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descripcionPuestoDataGridViewTextBoxColumn
            // 
            this.descripcionPuestoDataGridViewTextBoxColumn.DataPropertyName = "descripcionPuesto";
            this.descripcionPuestoDataGridViewTextBoxColumn.HeaderText = "descripcionPuesto";
            this.descripcionPuestoDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.descripcionPuestoDataGridViewTextBoxColumn.Name = "descripcionPuestoDataGridViewTextBoxColumn";
            this.descripcionPuestoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // directivosDataGridViewCheckBoxColumn
            // 
            this.directivosDataGridViewCheckBoxColumn.DataPropertyName = "directivos";
            this.directivosDataGridViewCheckBoxColumn.HeaderText = "directivos";
            this.directivosDataGridViewCheckBoxColumn.MinimumWidth = 8;
            this.directivosDataGridViewCheckBoxColumn.Name = "directivosDataGridViewCheckBoxColumn";
            this.directivosDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // empleadoBindingSource
            // 
            this.empleadoBindingSource.DataMember = "Empleado";
            this.empleadoBindingSource.DataSource = this.coppelDataSet;
            // 
            // coppelDataSet
            // 
            this.coppelDataSet.DataSetName = "CoppelDataSet";
            this.coppelDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabDirectivos
            // 
            this.tabDirectivos.Controls.Add(this.dgvDirectivos);
            this.tabDirectivos.Location = new System.Drawing.Point(4, 37);
            this.tabDirectivos.Margin = new System.Windows.Forms.Padding(4);
            this.tabDirectivos.Name = "tabDirectivos";
            this.tabDirectivos.Padding = new System.Windows.Forms.Padding(4);
            this.tabDirectivos.Size = new System.Drawing.Size(1579, 520);
            this.tabDirectivos.TabIndex = 1;
            this.tabDirectivos.Text = "Directivos";
            this.tabDirectivos.UseVisualStyleBackColor = true;
            // 
            // dgvDirectivos
            // 
            this.dgvDirectivos.AllowUserToAddRows = false;
            this.dgvDirectivos.AllowUserToDeleteRows = false;
            this.dgvDirectivos.AutoGenerateColumns = false;
            this.dgvDirectivos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDirectivos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDirectivos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numEmpleadoDataGridViewTextBoxColumn,
            this.numCentroSupervisaDataGridViewTextBoxColumn,
            this.prestacionesDataGridViewCheckBoxColumn});
            this.dgvDirectivos.DataSource = this.directivosBindingSource;
            this.dgvDirectivos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDirectivos.Location = new System.Drawing.Point(4, 4);
            this.dgvDirectivos.MultiSelect = false;
            this.dgvDirectivos.Name = "dgvDirectivos";
            this.dgvDirectivos.ReadOnly = true;
            this.dgvDirectivos.RowHeadersWidth = 62;
            this.dgvDirectivos.RowTemplate.Height = 28;
            this.dgvDirectivos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDirectivos.Size = new System.Drawing.Size(1571, 512);
            this.dgvDirectivos.TabIndex = 0;
            // 
            // numEmpleadoDataGridViewTextBoxColumn
            // 
            this.numEmpleadoDataGridViewTextBoxColumn.DataPropertyName = "numEmpleado";
            this.numEmpleadoDataGridViewTextBoxColumn.HeaderText = "numEmpleado";
            this.numEmpleadoDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.numEmpleadoDataGridViewTextBoxColumn.Name = "numEmpleadoDataGridViewTextBoxColumn";
            this.numEmpleadoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // numCentroSupervisaDataGridViewTextBoxColumn
            // 
            this.numCentroSupervisaDataGridViewTextBoxColumn.DataPropertyName = "numCentroSupervisa";
            this.numCentroSupervisaDataGridViewTextBoxColumn.HeaderText = "numCentroSupervisa";
            this.numCentroSupervisaDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.numCentroSupervisaDataGridViewTextBoxColumn.Name = "numCentroSupervisaDataGridViewTextBoxColumn";
            this.numCentroSupervisaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // prestacionesDataGridViewCheckBoxColumn
            // 
            this.prestacionesDataGridViewCheckBoxColumn.DataPropertyName = "prestaciones";
            this.prestacionesDataGridViewCheckBoxColumn.HeaderText = "prestaciones";
            this.prestacionesDataGridViewCheckBoxColumn.MinimumWidth = 8;
            this.prestacionesDataGridViewCheckBoxColumn.Name = "prestacionesDataGridViewCheckBoxColumn";
            this.prestacionesDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // directivosBindingSource
            // 
            this.directivosBindingSource.DataMember = "Directivos";
            this.directivosBindingSource.DataSource = this.coppelDataSet;
            // 
            // tabCentroTrabajo
            // 
            this.tabCentroTrabajo.Controls.Add(this.dgvCentroTrabajo);
            this.tabCentroTrabajo.Location = new System.Drawing.Point(4, 37);
            this.tabCentroTrabajo.Margin = new System.Windows.Forms.Padding(4);
            this.tabCentroTrabajo.Name = "tabCentroTrabajo";
            this.tabCentroTrabajo.Size = new System.Drawing.Size(1579, 520);
            this.tabCentroTrabajo.TabIndex = 2;
            this.tabCentroTrabajo.Text = "Centro de Trabajo";
            this.tabCentroTrabajo.UseVisualStyleBackColor = true;
            // 
            // dgvCentroTrabajo
            // 
            this.dgvCentroTrabajo.AllowUserToAddRows = false;
            this.dgvCentroTrabajo.AllowUserToDeleteRows = false;
            this.dgvCentroTrabajo.AutoGenerateColumns = false;
            this.dgvCentroTrabajo.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCentroTrabajo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCentroTrabajo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numCentroDataGridViewTextBoxColumn,
            this.nombreCentroDataGridViewTextBoxColumn,
            this.ciudadDataGridViewTextBoxColumn});
            this.dgvCentroTrabajo.DataSource = this.centrodeTrabajoBindingSource;
            this.dgvCentroTrabajo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvCentroTrabajo.Location = new System.Drawing.Point(0, 0);
            this.dgvCentroTrabajo.MultiSelect = false;
            this.dgvCentroTrabajo.Name = "dgvCentroTrabajo";
            this.dgvCentroTrabajo.ReadOnly = true;
            this.dgvCentroTrabajo.RowHeadersWidth = 62;
            this.dgvCentroTrabajo.RowTemplate.Height = 28;
            this.dgvCentroTrabajo.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCentroTrabajo.Size = new System.Drawing.Size(1579, 520);
            this.dgvCentroTrabajo.TabIndex = 0;
            // 
            // numCentroDataGridViewTextBoxColumn
            // 
            this.numCentroDataGridViewTextBoxColumn.DataPropertyName = "numCentro";
            this.numCentroDataGridViewTextBoxColumn.HeaderText = "numCentro";
            this.numCentroDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.numCentroDataGridViewTextBoxColumn.Name = "numCentroDataGridViewTextBoxColumn";
            this.numCentroDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nombreCentroDataGridViewTextBoxColumn
            // 
            this.nombreCentroDataGridViewTextBoxColumn.DataPropertyName = "nombreCentro";
            this.nombreCentroDataGridViewTextBoxColumn.HeaderText = "nombreCentro";
            this.nombreCentroDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.nombreCentroDataGridViewTextBoxColumn.Name = "nombreCentroDataGridViewTextBoxColumn";
            this.nombreCentroDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ciudadDataGridViewTextBoxColumn
            // 
            this.ciudadDataGridViewTextBoxColumn.DataPropertyName = "ciudad";
            this.ciudadDataGridViewTextBoxColumn.HeaderText = "ciudad";
            this.ciudadDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.ciudadDataGridViewTextBoxColumn.Name = "ciudadDataGridViewTextBoxColumn";
            this.ciudadDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // centrodeTrabajoBindingSource
            // 
            this.centrodeTrabajoBindingSource.DataMember = "CentrodeTrabajo";
            this.centrodeTrabajoBindingSource.DataSource = this.coppelDataSet;
            // 
            // tabPuestos
            // 
            this.tabPuestos.Controls.Add(this.dgvPuestos);
            this.tabPuestos.Location = new System.Drawing.Point(4, 37);
            this.tabPuestos.Margin = new System.Windows.Forms.Padding(4);
            this.tabPuestos.Name = "tabPuestos";
            this.tabPuestos.Size = new System.Drawing.Size(1579, 520);
            this.tabPuestos.TabIndex = 3;
            this.tabPuestos.Text = "Puestos";
            this.tabPuestos.UseVisualStyleBackColor = true;
            // 
            // dgvPuestos
            // 
            this.dgvPuestos.AllowUserToAddRows = false;
            this.dgvPuestos.AllowUserToDeleteRows = false;
            this.dgvPuestos.AutoGenerateColumns = false;
            this.dgvPuestos.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPuestos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPuestos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numPuestoDataGridViewTextBoxColumn1,
            this.puestoDataGridViewTextBoxColumn,
            this.descripcionDataGridViewTextBoxColumn});
            this.dgvPuestos.DataSource = this.puestosBindingSource;
            this.dgvPuestos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvPuestos.Location = new System.Drawing.Point(0, 0);
            this.dgvPuestos.MultiSelect = false;
            this.dgvPuestos.Name = "dgvPuestos";
            this.dgvPuestos.ReadOnly = true;
            this.dgvPuestos.RowHeadersWidth = 62;
            this.dgvPuestos.RowTemplate.Height = 28;
            this.dgvPuestos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPuestos.Size = new System.Drawing.Size(1579, 520);
            this.dgvPuestos.TabIndex = 0;
            // 
            // numPuestoDataGridViewTextBoxColumn1
            // 
            this.numPuestoDataGridViewTextBoxColumn1.DataPropertyName = "numPuesto";
            this.numPuestoDataGridViewTextBoxColumn1.HeaderText = "numPuesto";
            this.numPuestoDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.numPuestoDataGridViewTextBoxColumn1.Name = "numPuestoDataGridViewTextBoxColumn1";
            this.numPuestoDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // puestoDataGridViewTextBoxColumn
            // 
            this.puestoDataGridViewTextBoxColumn.DataPropertyName = "puesto";
            this.puestoDataGridViewTextBoxColumn.HeaderText = "puesto";
            this.puestoDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.puestoDataGridViewTextBoxColumn.Name = "puestoDataGridViewTextBoxColumn";
            this.puestoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descripcionDataGridViewTextBoxColumn
            // 
            this.descripcionDataGridViewTextBoxColumn.DataPropertyName = "descripcion";
            this.descripcionDataGridViewTextBoxColumn.HeaderText = "descripcion";
            this.descripcionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.descripcionDataGridViewTextBoxColumn.Name = "descripcionDataGridViewTextBoxColumn";
            this.descripcionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // puestosBindingSource
            // 
            this.puestosBindingSource.DataMember = "Puestos";
            this.puestosBindingSource.DataSource = this.coppelDataSet;
            // 
            // puestosTableAdapter
            // 
            this.puestosTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CentrodeTrabajoTableAdapter = this.centrodeTrabajoTableAdapter;
            this.tableAdapterManager.DirectivosTableAdapter = this.directivosTableAdapter;
            this.tableAdapterManager.EmpleadoTableAdapter = this.empleadoTableAdapter;
            this.tableAdapterManager.PuestosTableAdapter = this.puestosTableAdapter;
            this.tableAdapterManager.UpdateOrder = AppCoppel.CoppelDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // centrodeTrabajoTableAdapter
            // 
            this.centrodeTrabajoTableAdapter.ClearBeforeFill = true;
            // 
            // directivosTableAdapter
            // 
            this.directivosTableAdapter.ClearBeforeFill = true;
            // 
            // empleadoTableAdapter
            // 
            this.empleadoTableAdapter.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 28F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1747, 506);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AppCoppel";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabEmpleados.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEmpleados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.empleadoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.coppelDataSet)).EndInit();
            this.tabDirectivos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDirectivos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.directivosBindingSource)).EndInit();
            this.tabCentroTrabajo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCentroTrabajo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.centrodeTrabajoBindingSource)).EndInit();
            this.tabPuestos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPuestos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.puestosBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabEmpleados;
        private System.Windows.Forms.TabPage tabDirectivos;
        private System.Windows.Forms.TabPage tabCentroTrabajo;
        private System.Windows.Forms.TabPage tabPuestos;
        private System.Windows.Forms.DataGridView dgvEmpleados;
        private System.Windows.Forms.DataGridView dgvDirectivos;
        private System.Windows.Forms.DataGridView dgvCentroTrabajo;
        private System.Windows.Forms.DataGridView dgvPuestos;
        private CoppelDataSet coppelDataSet;
        private System.Windows.Forms.BindingSource puestosBindingSource;
        private CoppelDataSetTableAdapters.PuestosTableAdapter puestosTableAdapter;
        private CoppelDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private CoppelDataSetTableAdapters.CentrodeTrabajoTableAdapter centrodeTrabajoTableAdapter;
        private System.Windows.Forms.BindingSource centrodeTrabajoBindingSource;
        private CoppelDataSetTableAdapters.DirectivosTableAdapter directivosTableAdapter;
        private System.Windows.Forms.BindingSource directivosBindingSource;
        private CoppelDataSetTableAdapters.EmpleadoTableAdapter empleadoTableAdapter;
        private System.Windows.Forms.BindingSource empleadoBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn numEmpleadoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellidoPDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellidoMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaNacimientoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rFCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numCentroDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn numPuestoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcionPuestoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn directivosDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numEmpleadoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numCentroSupervisaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn prestacionesDataGridViewCheckBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numCentroDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreCentroDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ciudadDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numPuestoDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn puestoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcionDataGridViewTextBoxColumn;
    }
}

